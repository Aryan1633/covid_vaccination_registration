const express = require('express');
const bodyParser = require('body-parser');
const mysql = require('mysql');

const registration_process = require('./javascript/registration_process');
const login_process = require('./javascript/login_process');
const admin_process = require('./javascript/admin_process');

const app = express();
// Set EJS as the template engine
app.set('view engine', 'ejs');

app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));

// Create a MySQL connection
const connection = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "12Chakri@#",
  database: "vaccination_app" 
});

connection.connect((err) => {
  if (err) {
    console.error('Error connecting to database:', err);
    return;
  }
  console.log('Connected to database.');
});

// Route for registration
app.post('/registration_process', registration_process.handleRegistration);

// Route for login
app.post('/login_process', login_process.handleLogin);

// Custom middleware to extract user details from the request body
function extractUserDetails(req, res, next) {
  const userData = req.body;
  req.first_name = userData.first_name;
  req.last_name = userData.last_name;
  req.email = userData.email;
  console.log(userData);
  next();
}
app.post('/Users', (req, res) => {
  res.sendStatus(200);
});

app.post('/BookedDetails', (req, res) => {
  const center = req.body.center;
  const workingHours = req.body.workingHours;
  const id1 = req.body.id1;
  const firstName = req.body.first_name;
  const lastName = req.body.last_name;
  const email = req.body.email;
  const booking_status = 'approved';
  console.log(firstName);
  console.log(lastName);
  console.log(email);
  console.log(center);
  console.log(workingHours);
  console.log(id1);

  const sql = 'UPDATE vaccination_centers SET `limit` = `limit` - 1 WHERE id = ?';
  const sql1 = 'UPDATE users SET booking_status = ?, centre = ?, working_hours = ? WHERE first_name = ? AND last_name = ? AND email = ?';
  const values = [id1];
  const values1 = [booking_status, center, workingHours,firstName,lastName,email];

  connection.query(sql, values, (error, results) => {
    if (error) {
      console.error('Error decrementing limit:', error);
      res.status(500).send('Error decrementing limit.');
      return;
    }
    if (results.affectedRows === 0) {
      console.log('No rows were affected by the update query.');
      // Handle the case where the update query didn't affect any rows
      // You can choose to send an appropriate response or take another action.
    } else {
      console.log('Limit decremented successfully');
      console.log(results);

      //Insert data into the users table after the center is decremented
      connection.query(sql1, values1, (error, results) => {
        if (error) {
          console.error('ERROR in assigning to users', error);
          res.status(500).send('Error inserting your details');
          return;
        } else {
          console.log('User details updated successfully:', results);
          // Send a custom message along with status code 200
          res.status(200).send('Your slot has been booked successfully!');
        }
      });
      // Send a success response to the client
      res.redirect('/');
    }
  });
});


// Route for admin
app.post('/admin_process', admin_process.handleAdmin);

app.get('/us', (req, res) => {
  // Retrieve data from the database
  connection.query('SELECT * FROM users', (error, results) => {
    if (error) {
      console.error('Error executing query:', error);
      res.status(500).send('Error retrieving data from database.');
      return;
    }
    // Send the retrieved data as JSON
    console.log(results);
    res.json(results);
  });
});

// Serve the data.html file
app.get('/slots', (req, res) => {
  res.sendFile(__dirname + '/public/slots.html');
});


// Serve the data.html file
app.get('/userdetail', (req, res) => {
  res.sendFile(__dirname + '/public/userdetail.html');
});

app.get('/sl', (req, res) => {
  // Retrieve data from the database
  connection.query('SELECT * FROM vaccination_centers', (error, results) => {
    if (error) {
      console.error('Error executing query:', error);
      res.status(500).send('Error retrieving data from database.');
      return;
    }
   //console.log(results);
    // Call the function to send the retrieved data to the client
    res.json(results);
  });
});

//route to adminUse
app.get('/adminUse.html', (req, res) => {
  res.sendFile(__dirname + '/public/adminUse.html');
});

// Route for the main page (index.html)
app.get('/', (req, res) => {
  res.sendFile(__dirname + '/public/index.html');
});

app.listen(3000, () => {
  console.log('Server started on port 3000');
});
