const dbOperations = require('../database/dbOperations');

const handleAdmin = (req, res) => {
  const first_name = req.body.first_name;
  const last_name = req.body.last_name;
  const email = req.body.email;
  const password = req.body.password;
  console.log("This is the admin page");

  // Perform login logic here
  dbOperations.validateAdmin(first_name, last_name, email, password, (err, isValid) => {
    if (err) {
      // Handle database error
      console.error(err);
      res.status(500).send('An error occurred');
    } else {
      if (isValid) {
        // Send a response to the client if login is successful
        res.redirect('/adminUse.html');
      } else {
        // Send a response to the client if login is unsuccessful
        res.send('Invalid email or password');
      }
    }
  });
};

module.exports = {
  handleAdmin
};
