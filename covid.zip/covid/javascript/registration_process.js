const dbOperations = require('../database/dbOperations');

const handleRegistration = (req, res) => {
  const first_name = req.body.first_name;
  const last_name = req.body.last_name;
  const email = req.body.email;
  const password = req.body.password;
  const booking_status = 'Pending';
  const center = 'Not Declared';
  const working_hours = 'Not Declared';
  console.log("This is the registration page");

  // Call the insertUser function from dbOperations.js
  dbOperations.insertUser(first_name, last_name, email, password, booking_status, center, working_hours);

  // Send a response to the client
  res.send(`
    <script>
      // JavaScript code to display popup and enable auto-save
      window.onload = function() {
        alert('Registration successful');
        // Enable auto-save option
        // Add your auto-save logic here
      }
    </script>
    Registration successful
  `);
};

module.exports = {
  handleRegistration
};
