const dbOperations = require('../database/dbOperations');

const handleLogin = (req, res) => {
  const email = req.body.email;
  const password = req.body.password;
  console.log("This is the login page");

  // Perform login logic here
  dbOperations.validateUser(email, password, (err, userDetails) => {
    if (err) {
      // Handle database error
      console.error(err);
      res.status(500).send('An error occurred');
    } else {
      if (userDetails) {
        // Redirect to the user detail page with the user details as query parameters
        const queryString = Object.keys(userDetails)
          .map((key) => `${encodeURIComponent(key)}=${encodeURIComponent(userDetails[key])}`)
          .join("&");
        const redirectUrl = `/userdetail.html?${queryString}`;
        res.redirect(redirectUrl);
      } else {
        // Send a response to the client if login is unsuccessful
        res.send('Invalid email or password');
      }
    }
  });
};

module.exports = {
  handleLogin
};
